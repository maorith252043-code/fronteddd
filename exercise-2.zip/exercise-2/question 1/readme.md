Main differences between HTML and JSX
After researching, I found that while JSX looks like HTML, it has a few specific rules because it is actually JavaScript. Here are the main differences:

ClassName instead of Class: In JSX, you can't use class because it's a reserved word in JavaScript, so you have to use className instead.

CamelCase for Everything: Unlike HTML's lowercase style, JSX uses camelCase for attributes and events—so onclick becomes onClick.

Closing All Tags: Every tag in JSX must be closed. Even tags like <img> or <br> that usually stand alone in HTML need a closing slash like <img />.

JavaScript Power: You can put actual JavaScript logic directly into your UI by wrapping it in curly braces { }, which you can't do in standard HTML.