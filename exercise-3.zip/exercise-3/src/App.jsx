import Main from "./components/Main";

function App() {
  return (
    <>
      <Header />
      <Main /> 
      <Footer />
    </>
  );
}