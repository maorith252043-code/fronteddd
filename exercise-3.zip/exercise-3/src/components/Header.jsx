export default function Header() {
  return (
    <header className="block">
      <h1>WELCOME !</h1>
    </header>
  );
}